"""
savecode/__init__.py - Initialize the savecode package.
"""

# Optionally expose manager functions
from .manager import run_plugins, list_plugins