"""
savecode/plugins/__init__.py - Initialize the plugins package for savecode.
Version: 1.2.1
"""

# Import plugins to ensure they are registered.
from . import gather
from . import save
