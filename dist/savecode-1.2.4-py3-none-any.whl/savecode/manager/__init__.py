"""
savecode/manager/__init__.py - Initializes the manager module for savecode.
Version: 1.2.1
"""

from .manager import register_plugin, run_plugins, list_plugins