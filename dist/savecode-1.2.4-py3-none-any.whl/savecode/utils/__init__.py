"""
savecode/utils/__init__.py - Initializes the utils module for savecode.
Version: 1.2.1
"""

from .output_manager import configure_output_path