"""
savecode/__init__.py - Initialize the savecode package.
Version: 1.2.1
"""

# Optionally expose manager functions
from .manager import run_plugins, list_plugins